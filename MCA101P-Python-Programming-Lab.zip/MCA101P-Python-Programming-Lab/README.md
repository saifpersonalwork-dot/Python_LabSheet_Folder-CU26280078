# MCA101P — Python Programming Lab Solutions

Organized solutions for MCA I Semester (Session 2026–2027), based on the six supplied lab-sheet PDFs.

## Repository structure

- `Lab-01-Basic-Operations-and-Control-Statements/` — arithmetic and conditionals
- `Lab-02-Control-Statements-and-Loops/` — conditions, loops, number problems and patterns
- `Lab-03-String-and-List-Operations/` — strings and lists
- `Lab-04-List-and-Dictionary-Operations/` — lists and dictionaries
- `Lab-05-Tuple-Operations/` — tuple exercises
- `Lab-06-Set-Operations/` — set exercises

Each lab folder includes its original PDF, a lab-specific README, and one `.py` file per question.

## Requirements

- Python 3.10+ recommended
- No third-party packages required for most exercises

## How to run

Open a terminal in the relevant lab folder and run a file, for example:

```bash
python Q01_addition_of_two_integers.py
```

Programs are independent and request input from the terminal. Review the code and test with your own examples before submitting.
